#!/bin/sh
./convert.py --map ffffff 2 --map 000000 1 assets/*.png
